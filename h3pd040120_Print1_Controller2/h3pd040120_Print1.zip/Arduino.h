#ifndef __ARDUINO_H__
#define __ARDUINO_H__
#define F_CPU 16000000UL


#endif